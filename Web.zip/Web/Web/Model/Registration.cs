﻿namespace Web.Model
{
    public class Registration
    {
        public String First_Name { get; set; }
        public String Last_Name { get; set; }
        public String Email_ID { get; set; }
        public String Password { get; set; }
        



        //public int RID { get; set; }

    }
}
