﻿namespace Web.Model
{
    public class Response
    {
        public int statusCode { get; set; }

        public string statusmessage { get; set; }
    }
}
