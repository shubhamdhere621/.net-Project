﻿namespace API.Models
{
    public class BookCategory : ModelBase
    {
        public string Category { get; set; } = string.Empty;
        public string SubCategory { get; set; } = string.Empty;
    }
}
