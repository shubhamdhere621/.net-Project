﻿namespace API.Models
{
    public enum UserType
    {
        USER,
        ADMIN
    }
}
