﻿namespace API.Models
{
    public class ModelBase
    {
        public int Id { get; set; }
    }
}
